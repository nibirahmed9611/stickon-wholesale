<?php return array (
  'account.all-accounts' => 'App\\Http\\Livewire\\Account\\AllAccounts',
  'account.create-account' => 'App\\Http\\Livewire\\Account\\CreateAccount',
  'order-products.order-products' => 'App\\Http\\Livewire\\OrderProducts\\OrderProducts',
  'order.all-orders' => 'App\\Http\\Livewire\\Order\\AllOrders',
  'order.make-order' => 'App\\Http\\Livewire\\Order\\MakeOrder',
  'product.all-products' => 'App\\Http\\Livewire\\Product\\AllProducts',
  'product.create-product' => 'App\\Http\\Livewire\\Product\\CreateProduct',
  'product.edit-attribute' => 'App\\Http\\Livewire\\Product\\EditAttribute',
  'user.all-users' => 'App\\Http\\Livewire\\User\\AllUsers',
);