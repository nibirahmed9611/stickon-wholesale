@extends('layouts.app')

@section('content')

    @livewire('account.all-accounts')
    

@endsection