@extends('layouts.app')

@section('content')

    @livewire('account.create-account')
    

@endsection