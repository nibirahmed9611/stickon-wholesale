@extends('layouts.app')

@section('content')

    @livewire('order.make-order')
    

@endsection