@extends('layouts.app')

@section('content')

    @livewire('product.all-products')
    

@endsection