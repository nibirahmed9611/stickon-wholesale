@extends('layouts.app')

@section('content')

    @livewire('product.create-product')
    

@endsection