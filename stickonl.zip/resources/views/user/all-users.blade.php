@extends('layouts.app')

@section('content')

    @livewire('user.all-users')

@endsection