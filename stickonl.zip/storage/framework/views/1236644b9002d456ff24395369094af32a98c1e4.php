

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.edit-attribute',['productID'=>$id])->html();
} elseif ($_instance->childHasBeenRendered('XhEcfuu')) {
    $componentId = $_instance->getRenderedChildComponentId('XhEcfuu');
    $componentTag = $_instance->getRenderedChildComponentTagName('XhEcfuu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XhEcfuu');
} else {
    $response = \Livewire\Livewire::mount('product.edit-attribute',['productID'=>$id]);
    $html = $response->html();
    $_instance->logRenderedChild('XhEcfuu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/products/edit-attributes.blade.php ENDPATH**/ ?>