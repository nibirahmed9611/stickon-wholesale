

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('delete')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('delete')); ?>

                </div>
            <?php endif; ?>

            <?php if( auth()->user()->role == "Customer" ): ?>
                <a href="<?php echo e(route("refund.create")); ?>" class="btn btn-primary mb-2">Apply for Refund</a>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><b><?php echo e(__('All Users')); ?></b></div>

                <div class="card-body">
                    
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <table class="table table-responsive-md table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Applied at</th>
                                <th>Action</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $allRefunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($refund->title ?? ""); ?></td>
                                    <td><?php echo e($refund->description ? substr($refund->description, 0, 30) : ""); ?></td>
                                    <td><?php echo $refund->image ? "<a href=". asset( 'storage/' . $refund->image ) ."><img width='100px' src=". asset( 'storage/' . $refund->image ) ."></a>" : "Not Found"; ?></td>
                                    <td><?php echo e($refund->created_at ? $refund->created_at->format("d-M-Y") : "Not Found"); ?></td>
                                    <td><a class="btn btn-primary" href="<?php echo e(route("refund.show",['refund'=>$refund->id])); ?>">Show</a></td>
                                    <td>
                                        <form action="<?php echo e(route("refund.destroy",['refund'=>$refund->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("DELETE"); ?>
                                            <input onclick="return confirm('Are you sure you want to delete?')" class="btn btn-danger" type="submit" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6"><?php echo e(__('No Refund Found')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($allRefunds->links()); ?>


                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/refund/all-refunds.blade.php ENDPATH**/ ?>