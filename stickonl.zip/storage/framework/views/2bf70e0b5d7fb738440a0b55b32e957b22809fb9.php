

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.create-product')->html();
} elseif ($_instance->childHasBeenRendered('fKKFqg8')) {
    $componentId = $_instance->getRenderedChildComponentId('fKKFqg8');
    $componentTag = $_instance->getRenderedChildComponentTagName('fKKFqg8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fKKFqg8');
} else {
    $response = \Livewire\Livewire::mount('product.create-product');
    $html = $response->html();
    $_instance->logRenderedChild('fKKFqg8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/products/create-product.blade.php ENDPATH**/ ?>