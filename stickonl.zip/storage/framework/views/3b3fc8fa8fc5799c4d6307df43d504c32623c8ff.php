<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><?php echo e(__('Create Product')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form wire:submit.prevent="save">
                        <label for="">Name</label>   
                        <input wire:model.defer="product.name" type="text" class="form-control">
                        <?php $__errorArgs = ['product.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <label class="mt-1" for="">Price</label>   
                        <input wire:model.defer="product.price" type="number" class="form-control">
                        <?php $__errorArgs = ['product.price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <label class="mt-1" for="">Stock</label>   
                        <input wire:model.defer="product.quantity" type="number" class="form-control">
                        <?php $__errorArgs = ['product.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><br> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php if( count($attributes) > 0 ): ?>
                            <label class="mt-2" for="">Attributes</label>   
                        <?php endif; ?>

                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="text" class="form-control mt-1" wire:model.defer="attributes.<?php echo e($i); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="row">
                            <div class="col">
                                <button wire:click.prevent="addMore" class="btn btn-primary mt-3">Add a Attribute</button>
                            </div>
                            <div class="col text-right">
                                <input type="submit" value="Create" class="btn btn-success mt-3">
                            </div>
                        </div>
                    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\stickonl\resources\views/livewire/product/create-product.blade.php ENDPATH**/ ?>