
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><b><?php echo e(__('All Products')); ?></b></div>

                <div class="card-body">
                    
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <table class="table table-striped table-bordered table-hover table-responsive-md">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product</th>
                                <th>Attribute</th>
                                <th>Status</th>
                                <th>Quantity</th>
                                <th>Last Updated</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>

                                    <td><?php echo $orderProduct->image ? "<a href=". asset( 'storage/' . $orderProduct->image->path ) ."> <img src=" . asset( 'storage/' . $orderProduct->image->path ) . " width='100px' /> </a>"   : "Not Found"; ?></td>
                                    <td><?php echo e($orderProduct->product ? $orderProduct->product->name : "Not Found"); ?></td>
                                    <td><?php echo e($orderProduct->attribute ? $orderProduct->attribute->value : "Not Found"); ?></td>
                                    <td><?php echo e($orderProduct->status ?? "Not Found"); ?></td>
                                    <td><?php echo e($orderProduct->quantity ?? "Not Found"); ?></td>
                                    <td><?php echo e($orderProduct->updated_at->format("d-M-Y | h:i a")); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php echo e(__('No Orders Products Found')); ?>

                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="row">
                        <div class="col-md"></div>
                        <div class="col-md">
                            <?php if(session()->has('saved')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('saved')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <h4 class="mt-4">Overview</h4>
                            <table class="table table-striped table-bordered table-hover">
                                <tr>
                                    <td>Status</td>
                                    <?php if( auth()->user()->role == "Admin" ): ?>  
                                        <td>
                                            <select wire:model="status" class="form-control">
                                                <option value="In Process">In Process</option>
                                                <option value="In Delivery">In Delivery</option>
                                                <option value="Delivered">Delivered</option>
                                                <option value="Refunded">Refunded</option>
                                                <option value="Pending Payment">Pending Payment</option>
                                            </select>
                                        </td>
                                    <?php else: ?>
                                        <td><?php echo e($status); ?></td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td>Subtotal</td>
                                    <td><?php echo e($order['subtotal']); ?></td>
                                </tr>
                                <tr>
                                    <td>Discount</td>
                                    <?php if( auth()->user()->role == "Admin" ): ?>   
                                        <td><input type="number" class="form-control" wire:model.defer="discount"></td>
                                    <?php else: ?>
                                    <td><?php echo e($discount); ?></td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td>Total</td>
                                    <td><?php echo e($order['total']); ?></td>
                                </tr>
                                <tr>
                                    <td>Paid</td>
                                    <?php if( auth()->user()->role == "Admin" ): ?>  
                                        <td><input type="number" class="form-control" wire:model.defer="paid"></td>
                                    <?php else: ?>
                                        <td><?php echo e($paid); ?></td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td>Due</td>
                                    <td><?php echo e($order['due']); ?></td>
                                </tr>
                            </table>
                            <div class="row">
                                <div class="col">
                                    <a href="<?php echo e(route("orders.index")); ?>" class="btn btn-info text-light">Back</a>
                                    <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col text-right">
                                    <?php if( auth()->user()->role == "Admin" ): ?>  
                                        <button class="btn btn-success" wire:click="updateOrder">Save</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\stickonl\resources\views/livewire/order-products/order-products.blade.php ENDPATH**/ ?>