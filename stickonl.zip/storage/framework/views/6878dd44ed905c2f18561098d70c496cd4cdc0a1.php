

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.make-order')->html();
} elseif ($_instance->childHasBeenRendered('TKSpw64')) {
    $componentId = $_instance->getRenderedChildComponentId('TKSpw64');
    $componentTag = $_instance->getRenderedChildComponentTagName('TKSpw64');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TKSpw64');
} else {
    $response = \Livewire\Livewire::mount('order.make-order');
    $html = $response->html();
    $_instance->logRenderedChild('TKSpw64', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/order/make-order.blade.php ENDPATH**/ ?>