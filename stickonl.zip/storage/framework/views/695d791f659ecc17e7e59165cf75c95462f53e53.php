

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.all-orders')->html();
} elseif ($_instance->childHasBeenRendered('tc0Mf9r')) {
    $componentId = $_instance->getRenderedChildComponentId('tc0Mf9r');
    $componentTag = $_instance->getRenderedChildComponentTagName('tc0Mf9r');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tc0Mf9r');
} else {
    $response = \Livewire\Livewire::mount('order.all-orders');
    $html = $response->html();
    $_instance->logRenderedChild('tc0Mf9r', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/order/all-orders.blade.php ENDPATH**/ ?>