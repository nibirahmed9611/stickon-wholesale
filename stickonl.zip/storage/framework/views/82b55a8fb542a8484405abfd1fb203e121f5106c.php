

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('account.all-accounts')->html();
} elseif ($_instance->childHasBeenRendered('5YaDiVG')) {
    $componentId = $_instance->getRenderedChildComponentId('5YaDiVG');
    $componentTag = $_instance->getRenderedChildComponentTagName('5YaDiVG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5YaDiVG');
} else {
    $response = \Livewire\Livewire::mount('account.all-accounts');
    $html = $response->html();
    $_instance->logRenderedChild('5YaDiVG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/account/all-account.blade.php ENDPATH**/ ?>