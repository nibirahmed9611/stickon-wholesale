

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order-products.order-products', [
        'orderID'            => $orderID,
    ])->html();
} elseif ($_instance->childHasBeenRendered('LnHfacl')) {
    $componentId = $_instance->getRenderedChildComponentId('LnHfacl');
    $componentTag = $_instance->getRenderedChildComponentTagName('LnHfacl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LnHfacl');
} else {
    $response = \Livewire\Livewire::mount('order-products.order-products', [
        'orderID'            => $orderID,
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('LnHfacl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/order-products/order-products.blade.php ENDPATH**/ ?>