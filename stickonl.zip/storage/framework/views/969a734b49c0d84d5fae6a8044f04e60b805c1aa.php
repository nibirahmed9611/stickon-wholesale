
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session()->has('delete')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('delete')); ?>

                </div>
            <?php endif; ?>
            <a href="<?php echo e(route("product.create")); ?>" class="btn btn-primary mb-2">Add Product</a>
            <div class="card">
                <div class="card-header"><b><?php echo e(__('All Products')); ?></b></div>

                <div class="card-body">
                    
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Remaining Stock</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->price); ?></td>
                                    <td><?php echo e($product->quantity); ?></td>
                                    <td><a class="btn btn-primary" href="<?php echo e(route('product.edit',['product'=>$product->id])); ?>">Edit</a></td>
                                    <td>
                                        <form action="<?php echo e(route('product.destroy',['product'=>$product->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete?')">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5"><?php echo e(__('No Products Found')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($allProducts->links()); ?>


                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\stickonl\resources\views/livewire/product/all-products.blade.php ENDPATH**/ ?>