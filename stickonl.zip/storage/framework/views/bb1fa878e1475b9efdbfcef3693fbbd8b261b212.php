

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('account.create-account')->html();
} elseif ($_instance->childHasBeenRendered('xJUag08')) {
    $componentId = $_instance->getRenderedChildComponentId('xJUag08');
    $componentTag = $_instance->getRenderedChildComponentTagName('xJUag08');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xJUag08');
} else {
    $response = \Livewire\Livewire::mount('account.create-account');
    $html = $response->html();
    $_instance->logRenderedChild('xJUag08', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/account/create-account.blade.php ENDPATH**/ ?>