
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('delete')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('delete')); ?>

                </div>
            <?php endif; ?>
            <a href="<?php echo e(route("user.create")); ?>" class="btn btn-primary mb-2">Add User</a>
            <div class="card">
                <div class="card-header"><b><?php echo e(__('All Users')); ?></b></div>

                <div class="card-body">
                    
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <table class="table table-responsive-md table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Role</th>
                                <th>Joined</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($user->name ?? ""); ?></td>
                                    <td><?php echo e($user->email ?? ""); ?></td>
                                    <td><?php echo e($user->phone ?? ""); ?></td>
                                    <td><?php echo e($user->address ?? ""); ?></td>
                                    <td><?php echo e($user->role ?? ""); ?></td>
                                    <td><?php echo e($user->created_at ? $user->created_at->format("d-M-Y") : "Not Found"); ?></td>
                                    <td><a class="btn btn-primary" href="<?php echo e(route("user.edit",['user'=>$user->id])); ?>">Edit</a></td>
                                    <td>
                                        <form action="<?php echo e(route("user.destroy",['user'=>$user->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("DELETE"); ?>
                                            <input onclick="return confirm('Are you sure you want to delete?')" class="btn btn-danger" type="submit" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3"><?php echo e(__('No Users Found')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($allUsers->links()); ?>


                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\stickonl\resources\views/livewire/user/all-users.blade.php ENDPATH**/ ?>