

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product.all-products')->html();
} elseif ($_instance->childHasBeenRendered('BWvWx7p')) {
    $componentId = $_instance->getRenderedChildComponentId('BWvWx7p');
    $componentTag = $_instance->getRenderedChildComponentTagName('BWvWx7p');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BWvWx7p');
} else {
    $response = \Livewire\Livewire::mount('product.all-products');
    $html = $response->html();
    $_instance->logRenderedChild('BWvWx7p', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stickonl\resources\views/products/all-products.blade.php ENDPATH**/ ?>