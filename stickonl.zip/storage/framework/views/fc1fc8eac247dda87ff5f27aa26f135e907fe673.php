
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col mt-2">
                                <h4>
                                    <?php echo e(__('Order')); ?>

                                </h4>
                            </div>
                            <div class="col text-right" wire:loading>
                                <div class="spinner-border" role="status">
                                    <span class="visually-hidden"></span>
                                </div>
                            </div>
                        </div>
                    </div>
    
                    <div class="card-body">
                        
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <form wire:submit.prevent="order">
                            <?php $__currentLoopData = $orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mt-3 border p-3">

                                    <div class="col">
                                        <label class="">Image of your product</label>
                                        <div class="custom-file">
                                            <input type="file" wire:model.lazy="orderProducts.<?php echo e($index); ?>.photo" class="custom-file-input" id="customFile">
                                            <label class="custom-file-label" for="customFile">Upload design</label>
                                        </div>

                                        <img src="<?php echo e($orderProducts[$index]['photo'] != null ? $orderProducts[$index]['photo']->temporaryUrl(): 'https://via.placeholder.com/300x230'); ?>" width="300px" class="mt-2" style="border-radius: 5px;"> <br>

                                    </div>

                                    <div class="col">
                                        <label for="">Product</label>
                                        <select wire:model="orderProducts.<?php echo e($index); ?>.product" class="form-control">
                                            <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <label class="mt-5">Model/Size</label>                                            
                                        <select class="form-control" wire:model="orderProducts.<?php echo e($index); ?>.attribute">
                                            <option value="null">Select Model/Size</option>
                                            <?php
                                                if( $orderProducts[$index]['product'] != "" ){
                                                    $singleProduct = \App\Models\Product::findOrFail($orderProducts[$index]['product']);
                                                    $attributes = $singleProduct->attributes;

                                                    foreach ($attributes as $attribute) {
                                                        echo "<option value='$attribute->id'>$attribute->value</option>";
                                                    }
                                                }
                                            ?>
                                        </select>

                                        <label class="mt-5" for="">Quantity</label>
                                        <input type="number" wire:model.lazy="orderProducts.<?php echo e($index); ?>.quantity" class="form-control">
                                    </div>

                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            <div class="row">
                                <div class="col">
                                    <button class="btn btn-primary mt-3" wire:loading.attr="disabled" wire:click.prevent="addMore">Add More</button>
                                </div>
                                <div class="col text-right">
                                    <input type="submit" value="Order Now" class="btn btn-success mt-3">
                                </div>
                            </div>
                        </form>
                        
                    </div>
                        <?php $__empty_1 = true; $__currentLoopData = $productErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productErrors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <p class="text-danger ml-4"><?php echo $productErrors; ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    

<?php /**PATH C:\xampp\htdocs\stickonl\resources\views/livewire/order/make-order.blade.php ENDPATH**/ ?>